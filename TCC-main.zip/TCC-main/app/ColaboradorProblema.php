<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ColaboradorProblema extends Model
{
    protected $table = 'colaborador_problema';
}
