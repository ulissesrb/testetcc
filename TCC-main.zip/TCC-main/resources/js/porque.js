document.querySelector("#porque_link").onclick = () => {
    document.querySelector("#porque_form").submit()
}
