@extends('layouts.porques')

@section('num_min')primeiro{{""}}@endsection
@section('num_max')Primeiro{{""}}@endsection
@section('info') 
<details> <summary><img src="/img/interrog.png" height="20px" width="20px"></summary>
    <br>
    <p2> Exemplo do primeiro porquê:</p2><br><br>
    <p2> Por que a máquina parou? Aconteceu uma sobrecarga e o fusível estourou.</p2>
    <br>
</details><br>
@endsection
