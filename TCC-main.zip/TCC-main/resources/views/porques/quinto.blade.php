@extends('layouts.porques')

@section('num_ant')/quarto_porque{{""}}@endsection
@section('num_min')quinto{{""}}@endsection
@section('num_max')Quinto{{""}}@endsection
@section('info') 
<details> <summary><img src="/img/interrog.png" height="20px" width="20px"></summary>
    <br>
    <p2> Exemplo do quinto porquê:</p2><br><br>
    <p2> Por que a haste estava gasta? Não havia um filtro e os restos de metais entravam na bomba.  </p2>
    <br>
</details><br>
@endsection
