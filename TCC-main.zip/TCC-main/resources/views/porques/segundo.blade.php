@extends('layouts.porques')

@section('num_ant')/primeiro_porque{{""}}@endsection
@section('num_min')segundo{{""}}@endsection
@section('num_max')Segundo{{""}}@endsection
@section('info') 
<details> <summary><img src="/img/interrog.png" height="20px" width="20px"></summary>
    <br>
    <p2> Exemplo do segundo porquê:</p2><br><br>
    <p2> Por que aconteceu uma sobrecarga? O rolamento não estava suficientemente lubrificado. </p2>
    <br>
</details><br>
@endsection
