@extends('layouts.porques')

@section('num_ant')/segundo_porque{{""}}@endsection
@section('num_min')terceiro{{""}}@endsection
@section('num_max')Terceiro{{""}}@endsection
@section('info') 
<details> <summary><img src="/img/interrog.png" height="20px" width="20px"></summary>
    <br>
    <p2> Exemplo do terceiro porquê:</p2><br><br>
    <p2> Por que ele não estava suficientemente lubrificado? A bomba de lubrificação não estava bombeando suficientemente.  </p2>
    <br>
</details><br>
@endsection
