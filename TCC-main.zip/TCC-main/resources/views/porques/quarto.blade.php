@extends('layouts.porques')

@section('num_ant')/terceiro_porque{{""}}@endsection
@section('num_min')quarto{{""}}@endsection
@section('num_max')Quarto{{""}}@endsection
@section('info') 
<details> <summary><img src="/img/interrog.png" height="20px" width="20px"></summary>
    <br>
    <p2> Exemplo do quarto porquê:</p2><br><br>
    <p2> Por que ela não estava bombeando suficientemente? A haste da bomba de lubrificação estava gasta e causando ruídos. </p2>
    <br>
</details><br>
@endsection
