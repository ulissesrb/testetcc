&nbsp;&nbsp;&nbsp;{{ $colab->nome }}
<a href="/config_colaborador/{{$colab->id}}"><img src="/img/config.png" alt="logo"
width="25" height="25" align="right"></a>&nbsp;&nbsp;



<a href="email"><img src="/img/mail.png" alt="logo" width="25" height="25" align="right"></a><br><br>

