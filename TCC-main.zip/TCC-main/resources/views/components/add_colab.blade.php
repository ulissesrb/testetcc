<div id="colab">
    <div id="colab_name">{{ $colab->nome }}</div>
    <div id="colab_sign">+</div>
</div>
