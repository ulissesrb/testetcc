@extends('layouts.template')

@section('content')
<div id="mae">
    
<<<<<<< HEAD
=======

>>>>>>> 27e6d9f17d298f71f3fd7df82d6d0744dedc10bb


</div>

@endsection